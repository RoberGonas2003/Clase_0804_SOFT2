package Solucion.srp;

public class ReporteEnviar {
    
    public void enviarPorCorreo(Reporte r, String email) {
        // Lógica para enviar el informe por correo electrónico
        System.out.println("Enviando reporte a " + email);
    }
}
