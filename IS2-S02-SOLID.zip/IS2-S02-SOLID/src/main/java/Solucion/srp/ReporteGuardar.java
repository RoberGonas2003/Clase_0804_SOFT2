/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solucion.srp;

public class ReporteGuardar {
    
    public void guardarEnArchivo(Reporte r, String nombre) {
        // Lógica para guardar el informe en un archivo
        System.out.println("Guardando el reporte en " + nombre);
    }
}
