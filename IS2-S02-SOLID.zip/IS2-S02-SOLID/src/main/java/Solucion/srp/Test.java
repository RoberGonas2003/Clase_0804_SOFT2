package Solucion.srp;

public class Test {

    public static void main(String[] args) {
        System.out.println("*** test ***");
        Reporte r = new Reporte("Ejemplo","Ahora se cumple el principio SRP");
        
        // Guardar reporte
        ReporteGuardar rg = new ReporteGuardar();
        rg.guardarEnArchivo(r, "MiReporte.txt");
        
        // Enviar por Gmail
        ReporteEnviar re = new ReporteEnviar();
        re.enviarPorCorreo(r, "micorreo@ulima.edu.pe");
    }
}
