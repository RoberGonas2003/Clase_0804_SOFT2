package Solucion.ocp;

public class Figura {

    public double area();

}
