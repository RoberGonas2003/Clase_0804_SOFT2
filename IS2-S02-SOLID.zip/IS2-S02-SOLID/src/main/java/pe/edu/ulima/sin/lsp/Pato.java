package pe.edu.ulima.sin.lsp;

public class Pato extends Ave {

    @Override
    public void volar() {
        System.out.println("Pato volando ...");
    }
}
