
package Ejemplo.Demeter;

public class Test {
    public static void main(String[] args) {
        C c = new C("Hola");
        B b = new B(c);
        A a = new A(b);
        
        System.out.println(a.getB().getC().getNombre());
    }
}

