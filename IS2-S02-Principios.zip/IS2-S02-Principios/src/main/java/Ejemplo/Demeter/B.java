
package Ejemplo.Demeter;

public class B {
    private C c;

    public B(C c) {
        this.c = c;
    }

    public C getC() {
        return c;
    }
    
    
}
