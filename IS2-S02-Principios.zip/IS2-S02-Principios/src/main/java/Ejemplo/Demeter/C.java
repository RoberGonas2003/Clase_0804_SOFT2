
package Ejemplo.Demeter;

public class C {
    private String nombre;

    public C(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
}
